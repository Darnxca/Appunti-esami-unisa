typedef int item;


#define NULLITEM 0;
// Nullitem è un elemento che viene restituito quando la precondizione getFirst viene violata


int eq(item x, item y);

void input_item(item *x);

void output_item(item x);


