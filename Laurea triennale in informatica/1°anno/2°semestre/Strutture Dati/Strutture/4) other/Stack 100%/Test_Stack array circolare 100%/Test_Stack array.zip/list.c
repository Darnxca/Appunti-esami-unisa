#include <stdio.h>
#include <stdlib.h>
#include "item.h"
#include "list.h"


struct node{               
	item value;
	struct node *next;
}; 

struct c_list{
	struct node *first;  //punta al primo nodo // puntatore all’ultimo nodo di l1della lista	
	int size;            //numero di elementi in una lista
}


list newList(void)
{
	struct c_list *l;      
	l=malloc(sizeof(struct c_list));   //alloco memoria per la lista
	if(l != NULL)                      //se l non è null il primo elemento di l punta a NULL e la size viene settata a 0
	  {
		l->first=NULL;
		l->size=0;
	  }
	return l;    //ritorno la lista
}


int emptyList(list l)
{
       if(l==NULL)
	{
	   return -1;
	}
	return (l->size==0);
}

/*list constList(item val,list l)
{
	struct node *nuovo;
	nuovo=malloc(sizeof(struct node));
	if(nuovo!=NULL)
	   {
              nuovo ->value=val;
	      nuovo->next=l;
	      l=nuovo;
	   }
        return l;
}*/


int sizeList(list l)
{
	if(l==NULL)                 //se la lista l è NULL ritorno -1 (errore)
	   {                      
  		return -1;
	   }
	return l->size;
}


int posItem(list l,item val)
{
	if (l==NULL)   //se la lista l è vuota restituisco -1 (errore)
	  {
		return -1;
	  }

	int pos=0;    // mi salva la posizione dell'item 
	int found=0;  //viene settata ad 1 se l'item è stato trovato

	struct node *temp= l->first;  //il puntatore temp punta al primo elemento della lista l

	while(temp!=NULL&&!found)
	   {
		if(eq(temp->value,val))
		   {
 			found=1;    //elemento trovato
		   }
		else
		  {
			temp=temp->next;    //temp punta al prossimo elemento e contianua la ricerca nella lista
		        pos++;
		  }
		
		if(!found)
		{
		   pos=-1;	
		}  
		return pos;
	   }
}


item getItem(list l, int pos) 
{
	if(l==NULL)          //se l non esiste restituisco nullitem
	  {
		return NULLITEM
	  }
   
	if(pos<0||pos>=l->size)   //se la posizione inserita è minore di 0 o piu grande della grandzza della lista restituisco NULLITEM
	 {
		retun NULLITEM;   // precondizione non verificata
	 }	   

	struct node *temp=l->first;   //creo un puntatore temporaneo (temp) di tipo struct node che punta al primo elemento della lista 
	
	int i=0;

	while(i<pos)    //continuo il ciclo fino a quando non arrivo al nodo di posizione pos
	  {
		i++;
		temp=temp->next;  // temp punta al prossimo elemento
	  }

	return temp ->value   //ritorno il valore presente nel nodo della posizone pos
}





void inputList(int n)
{
	if(n<=0)
	  {
		return newList();
	  }

	item val;
	list l=newList()  //creo la nuova lista 

	printf("Inserire l'elemento di posizione 1: ");
	input_item(&val);
	l->first=makeNode(val,NULL);  // inserimento primo elemento 

	struct node *temp=l->first;  //puntatore all'ultimo nodo di l
	
	for(int i=1;i<n;i++)
	  {
		printf("Inserire l'elemento di posizione %d: ",i);
		input_item(&val);
		temp->next=makeNode(val,NULL);
		
		if(temp->next==NULL)
		   {
  			return -1;
		   }
		temp=temp->next;
	  }

	l->size=n;  //la size della lista è uguale al numero di elementi inseriti
	return l;
}


void outputList(list l)
{
	if(l==NULL)  //controllo se la lista l esiste
	  {
		return 0;
	  }

	int i=0;
	struct node *temp=l->first;

	while(temp != NULL)
	  {
		printf("L'elemento in posizione %d: ",i+1); 
		output_item(temp->value);
		printf("\n");
		
		temp->next;  //temp punta al successivo
 		i++;         //incremento i 
	  }
	return 1;  //l'operazione è andata a buon fine
}

static struct node* makeNode(item val, struct node* nxt)
{
	struct node *nuovo=malloc(sizeof(struct node));  //alloco memoria per la nuova struct "nuovo"
	if(nuovo != NULL)
	  {
		nuovo->value=val;
		nuovo->next=nxt;
	  }
	return nuovo;
}

static struct node* insertNode (struct node* n, int pos, item val)
{
	if(pos==0)
	  {
		return makeNode(val,n);
	  }

	int i=0;
	struct node* prec=n;
	while(i<pos-1)
	  {
		prec=prec->next;
		i++;
	  }

	n1=makeNode(val,prec->next);  //creo un nuovo nodo
	
	if(n1==NULL)
	  {	
		return NULL;   //makeNode non eè riuscito ad allocare memoria
	  }

	prec->next=n1;
	return n;
}


int insertList(list l,int pos,item val)
{
	  //controllare
	
	if(l==NULL)
	  { 
 		return 0;   //nel caso la lista non esiste
	  }
	
	if(pos<0||pos>l->size)  
	  {
 		return 0;    //nel caso che la posizione inserita sia minore di 0 o maggiore della lunghezza della lista
	  }	

	struct node *tmp = insertNode(l->first,pos,val);  //creo una struttura tmp 

	if(tmp==NULL)
	  {
		return 0;   // restituisco 0 se non sono riuscito ad inserire nella lista, esce senza modificafre la lista
	  }

	//se l'inserimento è riuscito allora modifico la lista 

	l->first= tmp;   //il primo elemento della lista è ugiale a tmp 
	l->size++;   //incremento la size di 1

	return 1;  
}

static struct node* removeNode(struct node* n, int pos)
{
   struct node *n1;     //puntatore al nodo che devo eliminare

   	if(pos==0)      //caso in cui devo eliminare in prima posione
          {
             n1=n;      //il puntatore n1 punta ad n  che è il puntaore al primo elemento della lista
 	     n=n->next;  //n punta all'elemento successivo che diviene il primo 
	     free(n1);  //libero n1
          }

         else      //caso di eliminazione in cui pos è maggiore di 0
	    {
		int i=0;   
		struct node *prec;  //puntatore al precendete (pos-1)
		
		while(i<pos-1)
		  {
  			prec=prec->next;   //scorriamo fino a pos-1 
			i++; 
			//Alla fine del ciclo, prec->next punta al nodo da eliminare.
		  }

		n1=prec->next;    //n1 punta al node che devo eliminare
                prec->next=n1->next;  //aggiorno il nodo che de o eliminare e lo faccio puntare al successivo
                free(n1);        //libero n1 che è il node che devo eliminare
	    }
}

int removeList(list l, int pos)
{
	if(l==NULL)
          {
	      return 0;    //caso in cui la lista non esite
	  }

	if(pos<0||pos>l->size)
          {
		return 0;      //precondizione non soddisfatta
	  }

       l->first = removeNode(l->first,pos); 
       l->size--;
       
       return 1;
}




list reverseList1(list l)
{
	if (l==NULL)
	  {
		return NULL;
	  }	

	list l1=newList();    //creiamo la nuova lista di output
	struct node *temp=l->first   // serve per scorrere la lista di input

//in questo ciclo si scorre la lista di input e si inseriscono i valori in testa alla nuova lista 
	while(temp!=NULL)
	  {
		l1->first=makeNode(temp->value,l1->first);

		if (l1->first==NULL)
		   {
			return -1;
		   }
		temp=temp->next;   //temp punta al prossimo nodo
	  }

   // l1->first è NULL se l è vuota o se makeNode non ha allocato memoria
	if(l1->first!=NULL)  //In questo ciclo si assegna alla nuova lista la size di quella di input
	  {
		l1->=l->size;
	  }

   // se l1->first è NULL allora l1->size è 0 (quella inizializzata da newList)
	return l1;   //ritorno la nuova lista  
}


list reverseList2(list l)   //inverte la lista senza crearne una nuova, inverterndo solo i puntatori
{
 
	if(l==NULL)
	  {
             return 0;
	  }

	struct node *n;     //serve per scorrere la lista 
	struct node *prec;  //punta al predecessore di n
	struct node *succ;  //usato per salvare il successore di n
	
	// si scorre la lista di input e n->next viene posto uguale a prec
	while(n!=NULL)
	  {
		succ=n->next;  //salviamo il successore
		n->next=prec;  //il successore di n diviene il suo predecessore
		prec=n;        //avanziamo prec sulla lista
		n=succ;        //avanziamo n sulla lista
	  }

	/* all’uscita del ciclo prec punta all’ultimo nodo della lista di input
che ora diventa il primo nodo della reversed list
*/
	l->first=prec;
	return 1;   //L'operazione è andata a buon fine
}



list cloneList(list l)
{
	
	if(l==NULL)
  	  {
             return NULL;   // si controlla se esiste la lista
	  }
	
	if(emptyList(l))
	  {
		return newList();
	  }

	struct node *temp=l->first;  //serve per scorrere la lista di input	
	
	list l1=newList();  //creiamo la nuova lista di output
	l1->first=makeNode(temp->value,NULL);    // creazione primo nodo

	struct node *temp1=l1->first;    // puntatore all’ultimo nodo di l1

	while(temp->next!=NULL)
	  {
		temp1->next=makeNode(temp->next->value,NULL);

		  if(temp1->next==NULL)
		    {
			return -1;
		    }

		temp=temp->next;
		temp1=temp1->next;
	  }


	l1->size=l->size;   // assegno la size della lista di input a quella clonata
	return l1;    //ritorno la lista clonata
}



int deleteList(list l)   //questa funzione cancella solo i nodi della lista e non l'intera lista
{
	
	if(l==NULL)
	  {
            return 0;    // controllo se la lista l esiste
	  }

	struct node *temp=l->first;   //serve a scorre la lista di input
	struct node *temp1;           //punta al nodo da eliminare

	while(temp!=NULL)
	  {
		temp1=temp;
		temp=temp->next;
		free(temp1);
	  }

	l->first=NULL;
	l->size=0;
	return 1;  //l'operazione è andata a buon fine
}

void destroyList(list *l)
{
	if(*l!=NULL)
	  {
		deleteList(l);
	  }

	free(*l);
	*l=NULL;
}











